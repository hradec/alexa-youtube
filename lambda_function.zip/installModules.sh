#!/bin/bash

/atomo/pipeline/libs/linux/x86_64/gcc-multi/python/3.7.5/bin/pip3 install --target ./modules bs4
/atomo/pipeline/libs/linux/x86_64/gcc-multi/python/3.7.5/bin/pip3 install --target ./modules youtube_search

