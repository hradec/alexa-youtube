#!/bin/bash

rm *.zip
zip -r ./lambda_function.zip ./*
